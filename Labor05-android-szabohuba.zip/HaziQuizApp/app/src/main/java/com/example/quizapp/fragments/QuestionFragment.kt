package com.example.quizapp.fragments

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import androidx.navigation.Navigation
import com.example.quizapp.R
import com.example.quizapp.classes.Question

private var questionCounter : Int = 0
private lateinit var currentQuestion : Question
private var answered : Boolean = true

class QuestionFragment : Fragment() {

    object achievemeent{
        var score : Int = 0
        var questionCountTotal : Int = 8
    }

    lateinit var next: Button
    lateinit var rbGroup: RadioGroup
    lateinit var rb1: RadioButton
    lateinit var rb2: RadioButton
    lateinit var rb3: RadioButton
    lateinit var rb4: RadioButton
    lateinit var question: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        var view = inflater.inflate(R.layout.fragmentbackup, container, false)


        next = view.findViewById<Button>(R.id.next)
        rbGroup = view.findViewById<RadioGroup>(R.id.rbGroup)
        rb1 = view.findViewById<RadioButton>(R.id.rb1)
        rb2 = view.findViewById<RadioButton>(R.id.rb2)
        rb3 = view.findViewById<RadioButton>(R.id.rb3)
        rb4 = view.findViewById<RadioButton>(R.id.rb4)
        question = view.findViewById<TextView>(R.id.question)

        showNextQuestion()



        next.setOnClickListener{
            if (next.text.toString() == "SUBMIT"){
                Navigation.findNavController(view).navigate(R.id.action_questionFragment_to_quizEndFragment)
            }
            next.error = null
            if (!answered) {
                if (rb1.isChecked || rb2.isChecked || rb3.isChecked || rb4.isChecked) {
                    next.error = null
                    checkAnswer()
                }
                else {
                    next.error = "Please select an answer"
                }
            }
            else {
                showNextQuestion()
            }
        }

        return view
    }

    private fun showNextQuestion() {
        when (questionCounter){
            0 -> { currentQuestion = Question("Kotlin is ___ interoperable with the Java programing language.","50%","98%","90%","100%",1) }
            1 -> { currentQuestion = Question("You can create an emulator to simulate the configuration of a particular type of Andriod device using a tool like ___.","Android SDK Manager","AVD Manager","Virtual Editor","Theme Editor",2) }
            2 -> { currentQuestion = Question("Kotlin is ___ interoperable with the Java programing language.","50%","98%","90%","100%",1) }
            3 -> { currentQuestion = Question("You can create an emulator to simulate the configuration of a particular type of Andriod device using a tool like ___.","Android SDK Manager","AVD Manager","Virtual Editor","Theme Editor",2) }
            4 -> { currentQuestion = Question("Kotlin is ___ interoperable with the Java programing language.","50%","98%","90%","100%",1) }
            5 -> { currentQuestion = Question("You can create an emulator to simulate the configuration of a particular type of Andriod device using a tool like ___.","Android SDK Manager","AVD Manager","Virtual Editor","Theme Editor",2) }
            6 -> { currentQuestion = Question("Kotlin is ___ interoperable with the Java programing language.","50%","98%","90%","100%",1) }
            7 -> { currentQuestion = Question("You can create an emulator to simulate the configuration of a particular type of Andriod device using a tool like ___.","Android SDK Manager","AVD Manager","Virtual Editor","Theme Editor",2) }

        }


        rbGroup.clearCheck()
        if (questionCounter < achievemeent.questionCountTotal) {
            question.text = currentQuestion.getQuestion()
            rb1.text = currentQuestion.getOption1()
            rb2.text = currentQuestion.getOption2()
            rb3.text = currentQuestion.getOption3()
            rb4.text = currentQuestion.getOption4()
            questionCounter++
            answered = false
        }
    }

    private fun checkAnswer() {
        answered = true

        var check : Int = 0
        if (rb1.isChecked){
            check = 1
        }
        if (rb2.isChecked){
            check = 2
        }
        if (rb3.isChecked){
            check = 3
        }
        if (rb4.isChecked){
            check = 4
        }
        if (check == currentQuestion.getAnswerNr()) {
            achievemeent.score++
        }

        if (questionCounter < achievemeent.questionCountTotal) {
            next.text = "NEXT"
        }
        else {
            next.text = "SUBMIT"
        }
    }

}

