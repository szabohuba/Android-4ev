package com.example.quizapp.fragments

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import androidx.navigation.Navigation
import com.example.quizapp.R

class QuizStartFragment : Fragment() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.fragment_quiz_start, container, false)


        val start = view.findViewById<Button>(R.id.start)
        val name = view.findViewById<EditText>(R.id.name)
        val chose = view.findViewById<Button>(R.id.choose)

        start.setOnClickListener{
            if (name.text.isEmpty()){
                name.error = "Wrong name!"
            }
            else {
                Navigation.findNavController(view).navigate(R.id.action_quizStartFragment_to_questionFragment)
            }
        }

        chose.setOnClickListener{
            Navigation.findNavController(view).navigate(R.id.action_quizStartFragment_to_quizEndFragment)
        }

        return view
    }

}