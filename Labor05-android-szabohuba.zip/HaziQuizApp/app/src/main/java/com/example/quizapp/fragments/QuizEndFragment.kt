package com.example.quizapp.fragments

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.navigation.Navigation
import com.example.quizapp.R

class QuizEndFragment : Fragment() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {

        var view = inflater.inflate(R.layout.fragment_quiz_end1, container, false)

        val score = QuestionFragment.achievemeent.score
        val total = QuestionFragment.achievemeent.questionCountTotal

        val result = view.findViewById<TextView>(R.id.result)
        val tryAgain = view.findViewById<Button>(R.id.tryAgain)

        result.text = "$score/$total points"

        tryAgain.setOnClickListener{
            Navigation.findNavController(view).navigate(R.id.action_quizEndFragment_to_quizStartFragment)
        }

        return view
    }

}