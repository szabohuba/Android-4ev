import java.time.*
import java.util.*
import java.util.Date
import kotlin.collections.ArrayList
import java.util.Random

abstract class Random

fun main() {

    //Problem1-test
    //val dict: IDictionary = TreeSetDictionary
    //println("Number of words: ${dict.size()}")
    //var word: String?
    // while(true){
    //print("What to find?")
    //word = readLine()
    //if( word.equals("quit")){
    //break
    //}
    //println("Result: ${word?.let { dict.find(it) }}")
    //}

//Problem 2 - test
    val name="Big Tom"
    println(name.monogram())


    val test= arrayListOf<String>("alma","korte","cseresznye")
    println(test.separator("~"))


    println(test.longest())

//Problem 3- test
//Main: Generate random dates. Check the validity of the generated date. Valid dates are
//stored in a list, while invalid ones are printed to the standard output. Repeat the
//generation process until 10 valid dates are generated.






}
    //Problem2- implementation

//Define an extension function that prints the monogram of a String containing the
//firstname and lastname. Example: John Smith → JS
//Loops are forbidden! Try to use split, map and joinToString!

    fun String.monogram():String{
        return this.split(" ").map{it[0]}.joinToString(" "){it.toString()}
    }

//Define a compact extension function that returns the elements of a strings’ list joined by
//a given separator!
//Example: (list: [“apple”, “pear”, “melon”]; separator: # ) → ”apple#pear#melon”

    fun ArrayList<String>.separator(aux:String):String{
        return this.joinToString(aux)
    }

//Define a compact extension function for a strings’ list that returns the longest string!
//Example: Longest [apple, pear, strawberry, melon] = strawberry
    fun ArrayList<String>.longest():String{
        var longer=0
        var aux:String=""
        for (i in this) {
            if(i.length > longer) {
                longer=i.length
                aux=i
            }
        }
        return aux.toString()
    }








