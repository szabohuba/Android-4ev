import java.io.File
import java.util.*

object  TreeSetDictionary:IDictionary{
    var words= TreeSet<String>()
    init{
        File(IDictionary.NAME).forEachLine{words.add(it)}
    }
    override fun add(word:String):Boolean{
        return words.add(word)
    }
    override fun size():Int{
        return words.size
    }
    override fun find(word:String):Boolean{
        return words.contains(word)
    }

}