import java.text.DateFormat
import java.text.spi.DateFormatProvider
import java.time.DayOfWeek
import java.time.Month
import java.time.Year
import java.util.zip.DataFormatException
import kotlin.Comparable



//Define a data class Date. The default constructor initializes the year, month and the day
//with the current date.

data class Date(var year: Year, var month: Month, var day: Int)


//Define an extension function that checks whether the year of the date is a leap year.
fun Date.leapyear():Boolean{
    return year.isLeap
}

//Define an extension function that checks whether the date is a valid one!
fun Date.valid():Boolean{
    if(leapyear() && month.equals("FEBRUARY") && day>28){
        return false
    }
    return month.value >=1 && month.value<=12 && day<=31 && day>=1
            && year.value>=1
}



