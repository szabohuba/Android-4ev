enum class DictionaryType {

        ARRAY_LIST,TREE_SET,HASH_SET
}