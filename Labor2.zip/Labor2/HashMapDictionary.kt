import java.io.File

object  HashSetDictionary:IDictionary{
    var words=HashSet<String>()
    init{
        File(IDictionary.NAME).forEachLine{words.add(it)}
    }
    override fun add(word:String):Boolean{
        return words.add(word)
    }
    override fun size():Int{
        return words.size
    }
    override fun find(word:String):Boolean{
        return words.contains(word)
    }

}