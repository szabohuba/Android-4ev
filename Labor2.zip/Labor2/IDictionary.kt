
//labor2-Define an IDictionary interface for an English dictionary containing the following
//operations: add a word, find a word and get the size of the dictionary

interface IDictionary
{
    fun add(word:String):Boolean
    fun size():Int
    fun find(word:String):Boolean


    // The dictionary’s name is a constant and should be defined using a companion object in
    // the interface.
    companion object{var NAME="G:\\IV.Ev\\labor2\\src\\main\\resources\\szotar.txt"}
}