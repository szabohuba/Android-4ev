import java.io.File

//Implement the IDictionary interface in a ListDictionary class that stores the
//words in a mutable list as shown in Fig. 1. ListDictionary should be a singleton!

object ListDictionary:IDictionary{
    var szo= mutableListOf<String>()
    init{
        File(IDictionary.NAME).forEachLine{szo.add(it)}
    }

    override fun add(word:String):Boolean{
        return szo.add(word)
    }
    override fun size():Int{
        return szo.size
    }
    //contains like in java
    override fun find(word:String):Boolean{
        return szo.contains(word)
    }

}


