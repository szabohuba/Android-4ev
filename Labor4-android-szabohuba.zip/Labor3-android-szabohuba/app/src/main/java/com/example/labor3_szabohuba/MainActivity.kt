package com.example.labor3_szabohuba

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import java.util.regex.Pattern


class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val button = findViewById<Button>(R.id.start)
        button.setOnClickListener(){

            callActivity()

        }


    }

    private fun callActivity() {
        val editText = findViewById<EditText>(R.id.name)
        val message = editText.text.toString()
        val intent = Intent(this,SecondSctivity::class.java).also {
            it.putExtra("EXTRA_MESSAGE",message)
            startActivity(it)
        }


    }


}